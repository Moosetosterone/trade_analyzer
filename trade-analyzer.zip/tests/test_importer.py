# tests/test_importer.py
from datetime import datetime

import pandas as pd
import pytest
import pytz

from data.importer import TradovateCSVImporter
from models.trade import TradovateFill


@pytest.fixture
def sample_fill_csv(tmp_path):
    """Creates a sample Orders-4.csv for testing."""
    data = {
        "orderId": ["12345", "67890"],
        "B/S": ["Buy", "Sell"],
        "Contract": ["MESU5", "MGCQ5"],
        "avgPrice": [6248.0, 3296.9],
        "filledQty": [1, 1],
        "Fill Time": ["06/30/2025 00:00:18", "06/30/2025 01:00:03"],
        "Status": ["Filled", "Filled"],
        "_tickSize": [0.25, 0.1],
    }
    df = pd.DataFrame(data)
    file_path = tmp_path / "Orders-4.csv"
    df.to_csv(file_path, index=False)
    return file_path


@pytest.fixture
def sample_cash_csv(tmp_path):
    """Creates a sample Cash History.csv for testing."""
    data = {
        "Timestamp": [
            "06/30/2025 00:00:18",
            "06/30/2025 00:00:18",
            "06/30/2025 00:00:18",
            "06/30/2025 00:00:18",
            "06/30/2025 01:00:03",
            "06/30/2025 01:00:03",
            "06/30/2025 01:00:03",
            "06/30/2025 01:00:03",
        ],
        "Contract": [
            "MESU5",
            "MESU5",
            "MESU5",
            "MESU5",
            "MGCQ5",
            "MGCQ5",
            "MGCQ5",
            "MGCQ5",
        ],
        "Cash Change Type": [
            " Commission",
            " Exchange Fee",
            " Clearing Fee",
            " Nfa Fee",
            " Commission",
            " Exchange Fee",
            " Clearing Fee",
            " Nfa Fee",
        ],
        "Delta": [-0.35, -0.35, -0.19, -0.02, -0.35, -0.50, -0.19, -0.02],
    }
    df = pd.DataFrame(data)
    file_path = tmp_path / "Cash History.csv"
    df.to_csv(file_path, index=False)
    return file_path


@pytest.fixture
def real_fill_csv():
    """Points to the actual Orders-4.csv."""
    return "/Users/nickmoose/dev/trade_analyzer/data/Orders-4.csv"


@pytest.fixture
def real_cash_csv():
    """Points to the actual Cash History.csv."""
    return "/Users/nickmoose/dev/trade_analyzer/data/Cash History.csv"


@pytest.fixture
def importer():
    """Creates a TradovateCSVImporter instance for tests (UTC)."""
    return TradovateCSVImporter(timezone="UTC", is_test=True)


@pytest.fixture
def real_importer():
    """Creates a TradovateCSVImporter instance for real data (EDT)."""
    return TradovateCSVImporter(timezone="UTC", is_test=False)


def test_import_fill_data(importer, sample_fill_csv):
    """Tests importing fill data from sample Orders-4.csv."""
    df = importer.import_data(fill_source=sample_fill_csv)

    assert len(df) == 2, "Should import two fills"
    assert set(df.columns) == {
        "timestamp",
        "symbol",
        "direction",
        "fill_price",
        "qty",
        "order_id",
        "commission",
    }

    # Check first fill
    assert df.iloc[0]["symbol"] == "CME_MINI:MESU2025"
    assert df.iloc[0]["direction"] == "buy"
    assert df.iloc[0]["fill_price"] == 6248.0
    assert df.iloc[0]["qty"] == 1
    assert df.iloc[0]["order_id"] == "12345"
    assert df.iloc[0]["commission"] == 0.0  # No cash CSV provided
    assert df.iloc[0]["timestamp"] == pd.Timestamp("2025-06-30 00:00:18", tz="UTC")

    # Check second fill
    assert df.iloc[1]["symbol"] == "COMEX_MINI:MGCQ2025"
    assert df.iloc[1]["direction"] == "sell"
    assert df.iloc[1]["fill_price"] == 3296.9
    assert df.iloc[1]["qty"] == 1
    assert df.iloc[1]["order_id"] == "67890"


def test_import_with_commission(importer, sample_fill_csv, sample_cash_csv):
    """Tests importing fill data with commissions from sample Cash History.csv."""
    df = importer.import_data(fill_source=sample_fill_csv, cash_source=sample_cash_csv)

    assert len(df) == 2, "Should import two fills"

    # Check commissions
    assert df.iloc[0]["commission"] == 0.91  # MESU5: 0.35 + 0.35 + 0.19 + 0.02
    assert df.iloc[1]["commission"] == 1.06  # MGCQ5: 0.35 + 0.50 + 0.19 + 0.02

    # Verify other fields remain correct
    assert df.iloc[0]["symbol"] == "CME_MINI:MESU2025"
    assert df.iloc[0]["direction"] == "buy"
    assert df.iloc[0]["fill_price"] == 6248.0
    assert df.iloc[0]["timestamp"] == pd.Timestamp("2025-06-30 00:00:18", tz="UTC")


def test_missing_fill_columns(importer, tmp_path):
    """Tests handling of missing columns in Orders-4.csv."""
    data = {
        "orderId": ["12345"],
        "B/S": ["Buy"],
        "Contract": ["MESU5"],
    }  # Missing avgPrice, filledQty, Fill Time
    df = pd.DataFrame(data)
    file_path = tmp_path / "invalid_fill.csv"
    df.to_csv(file_path, index=False)

    with pytest.raises(ValueError, match="Missing required fill columns"):
        importer.import_data(fill_source=file_path)


def test_missing_cash_columns(importer, sample_fill_csv, tmp_path):
    """Tests handling of missing columns in Cash History.csv."""
    data = {
        "Timestamp": ["06/30/2025 00:00:18"],
        "Contract": ["MESU5"],
    }  # Missing Cash Change Type, Delta
    df = pd.DataFrame(data)
    file_path = tmp_path / "invalid_cash.csv"
    df.to_csv(file_path, index=False)

    with pytest.raises(ValueError, match="Missing required cash columns"):
        importer.import_data(fill_source=sample_fill_csv, cash_source=file_path)


def test_missing_fees(importer, sample_fill_csv, tmp_path):
    """Tests handling of fills with no matching fees in Cash History.csv."""
    data = {
        "Timestamp": ["06/30/2025 00:00:18"],
        "Contract": ["MESU5"],
        "Cash Change Type": [" Commission"],
        "Delta": [-0.35],
    }
    df = pd.DataFrame(data)
    file_path = tmp_path / "partial_cash.csv"
    df.to_csv(file_path, index=False)

    result_df = importer.import_data(fill_source=sample_fill_csv, cash_source=file_path)

    assert result_df.iloc[0]["commission"] == 0.35  # Only Commission matched for MESU5
    assert result_df.iloc[1]["commission"] == 0.0  # No fees for MGCQ5


def test_invalid_direction(importer, tmp_path):
    """Tests handling of invalid direction values."""
    data = {
        "orderId": ["12345"],
        "B/S": ["Invalid"],  # Invalid direction
        "Contract": ["MESU5"],
        "avgPrice": [6248.0],
        "filledQty": [1],
        "Fill Time": ["06/30/2025 00:00:18"],
        "Status": ["Filled"],
        "_tickSize": [0.25],
    }
    df = pd.DataFrame(data)
    file_path = tmp_path / "invalid_direction.csv"
    df.to_csv(file_path, index=False)

    with pytest.raises(ValueError, match="Invalid direction: invalid"):
        importer.import_data(fill_source=file_path)


def test_invalid_qty_price(importer, tmp_path):
    """Tests handling of invalid qty or fill_price."""
    data = {
        "orderId": ["12345"],
        "B/S": ["Buy"],
        "Contract": ["MESU5"],
        "avgPrice": [-100.0],  # Negative price
        "filledQty": [0],  # Invalid qty
        "Fill Time": ["06/30/2025 00:00:18"],
        "Status": ["Filled"],
        "_tickSize": [0.25],
    }
    df = pd.DataFrame(data)
    file_path = tmp_path / "invalid_qty_price.csv"
    df.to_csv(file_path, index=False)

    with pytest.raises(
        ValueError, match="Fill price cannot be negative, and qty must be positive"
    ):
        importer.import_data(fill_source=file_path)


def test_timestamp_normalization(importer, sample_fill_csv):
    """Tests timestamp normalization to UTC for sample data."""
    df = importer.import_data(fill_source=sample_fill_csv)
    assert all(
        df["timestamp"].dt.tz == pytz.UTC for _ in range(len(df))
    ), "Timestamps should be in UTC"
    assert df.iloc[0]["timestamp"] == pd.Timestamp("2025-06-30 00:00:18", tz="UTC")


def test_symbol_mapping(importer, sample_fill_csv):
    """Tests symbol mapping to TradingView format for sample data."""
    df = importer.import_data(fill_source=sample_fill_csv)
    assert df.iloc[0]["symbol"] == "CME_MINI:MESU2025"
    assert df.iloc[1]["symbol"] == "COMEX_MINI:MGCQ2025"


def test_lsp_compliance(importer, sample_fill_csv):
    """Tests LSP compliance with DataImporter interface."""
    from data.importer import DataImporter

    assert isinstance(
        importer, DataImporter
    ), "TradovateCSVImporter should implement DataImporter"
    df = importer.import_data(fill_source=sample_fill_csv)
    assert isinstance(df, pd.DataFrame), "import_data should return a DataFrame"


@pytest.mark.timeout(10)
def test_real_data_import(real_importer, real_fill_csv, real_cash_csv):
    """Tests importing real Orders-4.csv and Cash History.csv."""
    fill_df = pd.read_csv(real_fill_csv)
    print(f"Number of fills in Orders-4.csv: {len(fill_df)}")
    print(f"Sample Fill Time: {fill_df['Fill Time'].head().tolist()}")
    print(f"Sample Contract: {fill_df['Contract'].head().tolist()}")
    cash_df = pd.read_csv(real_cash_csv)
    print(f"Number of cash rows: {len(cash_df)}")
    print(f"Sample Timestamp: {cash_df['Timestamp'].head().tolist()}")
    print(f"Sample Contract: {cash_df['Contract'].head().tolist()}")
    print(f"Sample Cash Change Type: {cash_df['Cash Change Type'].head().tolist()}")

    expected_fill_count = len(fill_df)

    df = real_importer.import_data(fill_source=real_fill_csv, cash_source=real_cash_csv)

    assert (
        len(df) == expected_fill_count
    ), f"Expected {expected_fill_count} fills, got {len(df)}"
    assert set(df.columns) == {
        "timestamp",
        "symbol",
        "direction",
        "fill_price",
        "qty",
        "order_id",
        "commission",
    }

    expected_commissions = {
        "CME_MINI:MESU2025": 0.91,
        "COMEX_MINI:MGCQ2025": 1.06,
        "NYMEX:MCLQ2025": 0.54,
        "CME:MBT1!": 1.71,
    }
    for symbol, expected in expected_commissions.items():
        fills = df[df["symbol"] == symbol]
        if not fills.empty:
            unique_commissions = fills["commission"].unique()
            print(f"Commissions for {symbol}: {unique_commissions}")
            if not any(abs(c - expected) <= 0.01 for c in unique_commissions):
                print(f"Unmatched fills for {symbol}:")
                print(
                    fills[["timestamp", "fill_price", "qty", "commission"]]
                    .head()
                    .to_string()
                )
            assert any(
                abs(c - expected) <= 0.01 for c in unique_commissions
            ), f"{symbol} commission expected ~{expected}, got {unique_commissions}"

    assert all(
        df["timestamp"].dt.tz == pytz.UTC for _ in range(len(df))
    ), "Timestamps should be in UTC"
    assert (
        df["direction"].isin(["buy", "sell"]).all()
    ), "Directions should be 'buy' or 'sell'"
    assert (df["qty"] > 0).all(), "Quantity must be positive"
    assert (df["fill_price"] >= 0).all(), "Fill price cannot be negative"


def test_whitespace_direction(importer, tmp_path):
    """Tests handling of whitespace in B/S values."""
    data = {
        "orderId": ["12345"],
        "B/S": [" Buy"],  # Leading space
        "Contract": ["MESU5"],
        "avgPrice": [6248.0],
        "filledQty": [1],
        "Fill Time": ["06/30/2025 00:00:18"],
        "Status": ["Filled"],
        "_tickSize": [0.25],
    }
    df = pd.DataFrame(data)
    file_path = tmp_path / "whitespace_direction.csv"
    df.to_csv(file_path, index=False)

    df = importer.import_data(fill_source=file_path)
    assert df.iloc[0]["direction"] == "buy", "Whitespace in B/S should be trimmed"
