# data/importer.py
from abc import ABC, abstractmethod
import pandas as pd
import json
from datetime import datetime, timedelta
import pytz
from typing import Dict, Optional, List
from models.trade import TradingViewSignal, TradovateFill
from data.cleanup import DataCleaner
import logging

# Configure logging for debugging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

class DataImporter(ABC):
    """Abstract base class for data importers (OCP, LSP)."""
    @abstractmethod
    def import_data(self, source: str) -> pd.DataFrame:
        pass

class TradingViewCSVImporter(DataImporter):
    """Imports TradingView signal data from CSV (SRP)."""
    def __init__(self, timezone: str = "UTC", symbol_mapping: Optional[Dict[str, str]] = None):
        self.timezone = pytz.timezone(timezone)
        self.symbol_mapping = symbol_mapping or {
            "COMEX_MINI:MGCQ2025": "MGCQ5",
            "CME_MINI:MESU2025": "MESU5",
            "CME:MBT1!": "MBTN5",
            "NYMEX:MCLQ2025": "MCLQ5"
        }
        self.required_json_fields = ["ticker", "action", "sentiment", "quantity", "price", "time"]

    def import_data(self, source: str) -> pd.DataFrame:
        """Imports CSV, extracts JSON, and maps to TradingViewSignal schema."""
        try:
            df = pd.read_csv(source)
            self._validate_columns(df)
            
            signals = []
            for _, row in df.iterrows():
                json_data = json.loads(row["Description"])
                self._validate_json(json_data)
                signal = self._map_to_signal(row, json_data)
                signals.append(signal)
            
            signals_df = pd.DataFrame([vars(signal) for signal in signals])
            signals_df = self._normalize_data(signals_df)
            return signals_df
        except Exception as e:
            raise ValueError(f"Failed to import TradingView CSV: {e}")

    def _validate_columns(self, df: pd.DataFrame) -> None:
        """Validates required CSV columns (SRP)."""
        required_columns = ["Alert ID", "Ticker", "Description", "Time"]
        if not all(col in df.columns for col in required_columns):
            raise ValueError(f"Missing required columns: {required_columns}")

    def _validate_json(self, json_data: Dict) -> None:
        """Validates JSON fields in Description (SRP)."""
        if not all(field in json_data for field in self.required_json_fields):
            raise ValueError(f"Missing required JSON fields: {self.required_json_fields}")

    def _map_to_signal(self, row: pd.Series, json_data: Dict) -> TradingViewSignal:
        """Maps CSV row and JSON to TradingViewSignal (SRP)."""
        return TradingViewSignal(
            timestamp=datetime.fromisoformat(json_data["time"].replace("Z", "+00:00")),
            symbol=json_data["ticker"],
            direction=json_data["sentiment"],
            signal_price=float(json_data["price"]),
            alert_id=str(row["Alert ID"]),
            strategy_id=None
        )

    def _normalize_data(self, df: pd.DataFrame) -> pd.DataFrame:
        """Normalizes timestamps and symbols (SRP)."""
        df["timestamp"] = pd.to_datetime(df["timestamp"]).dt.tz_convert(self.timezone)
        df["symbol"] = df["symbol"].map(self.symbol_mapping).fillna(df["symbol"])
        valid_directions = ["long", "flat"]
        if not df["direction"].isin(valid_directions).all():
            raise ValueError("Invalid direction values in data")
        return df

class TradovateCSVImporter(DataImporter):
    """Imports Tradovate fill data from CSV and merges commission data (SRP)."""
    def __init__(self, timezone: str = "UTC", symbol_mapping: Optional[Dict[str, str]] = None, is_test: bool = False):
        self.timezone = pytz.timezone(timezone)
        self.is_test = is_test  # Flag for test CSVs (assume UTC)
        self.symbol_mapping = symbol_mapping or {
            "MGCQ5": "COMEX_MINI:MGCQ2025",
            "MESU5": "CME_MINI:MESU2025",
            "MBTN5": "CME:MBT1!",
            "MCLQ5": "NYMEX:MCLQ2025"
        }
        self.required_fill_columns = ["orderId", "B/S", "Contract", "avgPrice", "filledQty", "Fill Time"]
        self.required_cash_columns = ["Timestamp", "Contract", "Cash Change Type", "Delta"]

    def import_data(self, fill_source: str, cash_source: Optional[str] = None) -> pd.DataFrame:
        """Imports Tradovate fill data and optionally merges commission from cash history."""
        try:
            # Read and clean fill data
            fill_df = pd.read_csv(fill_source)
            self._validate_fill_columns(fill_df)
            fill_df = DataCleaner.clean_fill_data(fill_df, self.is_test)
            
            # Read and clean cash history data if provided
            cash_df = pd.read_csv(cash_source) if cash_source else None
            if cash_df is not None:
                self._validate_cash_columns(cash_df)
                cash_df = DataCleaner.clean_cash_history(cash_df, self.is_test)
            
            # Map fills to TradovateFill
            fills = []
            for idx, row in fill_df.iterrows():
                if idx % 100 == 0:  # Log progress every 100 rows
                    logger.debug(f"Processing fill row {idx}/{len(fill_df)}")
                commission = self._calculate_commission(row, cash_df) if cash_df is not None else 0.0
                fill = self._map_to_fill(row, commission)
                fills.append(fill)
            
            # Convert to DataFrame
            fills_df = pd.DataFrame([vars(fill) for fill in fills])
            fills_df = self._normalize_data(fills_df)
            return fills_df
        except Exception as e:
            raise ValueError(f"Failed to import Tradovate CSV: {e}")

    def _validate_fill_columns(self, df: pd.DataFrame) -> None:
        """Validates required fill CSV columns (SRP)."""
        if not all(col in df.columns for col in self.required_fill_columns):
            raise ValueError(f"Missing required fill columns: {self.required_fill_columns}")

    def _validate_cash_columns(self, df: pd.DataFrame) -> None:
        """Validates required cash history CSV columns (SRP)."""
        if not all(col in df.columns for col in self.required_cash_columns):
            raise ValueError(f"Missing required cash columns: {self.required_cash_columns}")

    def _map_to_fill(self, row: pd.Series, commission: float) -> TradovateFill:
        """Maps CSV row to TradovateFill with commission (SRP)."""
        try:
            timestamp = row["Fill Time"]
            if pd.isna(timestamp):
                raise ValueError(f"Invalid Fill Time format: {row['Fill Time']}")
            
            direction = row["B/S"]
            if direction not in ["buy", "sell"]:
                raise ValueError(f"Invalid direction: {direction}")
            
            fill_price = float(row["avgPrice"])
            qty = int(row["filledQty"])
            if qty <= 0 or fill_price < 0:
                raise ValueError("Fill price cannot be negative, and qty must be positive")
            
            return TradovateFill(
                timestamp=timestamp,
                symbol=row["Contract"],
                direction=direction,
                fill_price=fill_price,
                qty=qty,
                order_id=str(row["orderId"]),
                commission=commission
            )
        except Exception as e:
            logger.error(f"Error mapping row: {row.to_dict()}, Error: {e}")
            raise ValueError(f"Error mapping row to TradovateFill: {e}")

    def _calculate_commission(self, fill_row: pd.Series, cash_df: pd.DataFrame) -> float:
        """Calculates total commission (including fees) for a fill by matching timestamp and contract."""
        if cash_df is None or cash_df.empty:
            return 0.0
        
        fill_time = fill_row["Fill Time"]
        contract = fill_row["Contract"]
        
        # Use ±15-second window
        time_window = timedelta(seconds=15)
        fee_types = ["commission", "exchange fee", "clearing fee", "nfa fee"]
        relevant_cash = cash_df[
            (abs(cash_df["Timestamp"] - fill_time) <= time_window) &
            (cash_df["Contract"].str.lower() == contract.lower()) &
            (cash_df["Cash Change Type"].isin(fee_types))
        ]
        
        # Debug logging
        if relevant_cash.empty:
            logger.debug(f"No fees found for Contract: {contract}, Fill Time: {fill_time}")
            logger.debug(f"Available contracts in cash_df: {cash_df['Contract'].unique()}")
            logger.debug(f"Available timestamps in cash_df (first 10): {cash_df['Timestamp'].head(10).tolist()}")
            logger.debug(f"Normalized fee types: {cash_df['Cash Change Type'].unique()}")
        else:
            logger.debug(f"Matched fees for Contract: {contract}, Fill Time: {fill_time}, Fees: {relevant_cash[['Cash Change Type', 'Delta']].to_dict()}")
        
        # Sum negative Delta values (fees are negative)
        total_fees = -relevant_cash["Delta"].sum() if not relevant_cash.empty else 0.0
        return round(total_fees, 2)

    def _normalize_data(self, df: pd.DataFrame) -> pd.DataFrame:
        """Normalizes timestamps and symbols (SRP)."""
        df["timestamp"] = pd.to_datetime(df["timestamp"]).dt.tz_convert(self.timezone)
        df["symbol"] = df["symbol"].map(self.symbol_mapping).fillna(df["symbol"])
        valid_directions = ["buy", "sell"]
        if not df["direction"].isin(valid_directions).all():
            raise ValueError(f"Invalid direction values in data: {df['direction'].unique()}")
        if (df["qty"] <= 0).any() or (df["fill_price"] < 0).any() or (df["commission"] < 0).any():
            raise ValueError("Quantity must be positive, fill price and commission cannot be negative")
        return df